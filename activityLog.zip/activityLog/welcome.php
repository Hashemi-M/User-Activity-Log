<?php
    session_Start();
    readfile("welcome.html");

?>