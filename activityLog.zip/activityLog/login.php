<form method="post" action="validate.php">
<p>Email</p>
<input type="text" name="email">
<p>Password</p>
<input type="password" name="password">
<input type="submit" value="login" name="login" >
</form>
